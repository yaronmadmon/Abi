/**
 * Time Pattern Matchers
 * Keywords and patterns for time-related extraction
 */

export const TIME_INDICATORS = {
  today: ["today", "this morning", "this afternoon", "this evening", "tonight"],
  tomorrow: ["tomorrow", "tomorrow morning", "tomorrow afternoon", "tomorrow evening"],
  thisWeek: ["this week", "sometime this week", "during the week"],
  nextWeek: ["next week"],
  later: ["later", "later today", "later tonight"],
  now: ["now", "right now", "immediately", "asap"],
};

export const DAYS_OF_WEEK = {
  monday: ["monday", "mon"],
  tuesday: ["tuesday", "tue", "tues"],
  wednesday: ["wednesday", "wed"],
  thursday: ["thursday", "thu", "thur", "thurs"],
  friday: ["friday", "fri"],
  saturday: ["saturday", "sat"],
  sunday: ["sunday", "sun"],
};

export const FREQUENCY_PATTERNS = [
  "every day",
  "daily",
  "every week",
  "weekly",
  "every month",
  "monthly",
  "every monday",
  "every tuesday",
  "every wednesday",
  "every thursday",
  "every friday",
  "every saturday",
  "every sunday",
  "once a week",
  "twice a week",
];

/**
 * Extract time reference from input
 */
export function extractTimeReference(input: string): {
  date?: string;
  day?: string;
  time?: string;
  isUrgent?: boolean;
} {
  const lower = input.toLowerCase();
  const result: {
    date?: string;
    day?: string;
    time?: string;
    isUrgent?: boolean;
  } = {};

  // Check for urgent indicators
  if (TIME_INDICATORS.now.some((indicator) => lower.includes(indicator))) {
    result.isUrgent = true;
    result.date = new Date().toISOString().split("T")[0];
    return result;
  }

  // Check for specific days
  for (const [day, variants] of Object.entries(DAYS_OF_WEEK)) {
    if (variants.some((v) => lower.includes(v))) {
      result.day = day;
      break;
    }
  }

  // Check for relative dates
  if (TIME_INDICATORS.today.some((indicator) => lower.includes(indicator))) {
    result.date = new Date().toISOString().split("T")[0];
  } else if (
    TIME_INDICATORS.tomorrow.some((indicator) => lower.includes(indicator))
  ) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    result.date = tomorrow.toISOString().split("T")[0];
  } else if (TIME_INDICATORS.thisWeek.some((indicator) => lower.includes(indicator))) {
    // This week - no specific date
    result.date = undefined;
  } else if (TIME_INDICATORS.nextWeek.some((indicator) => lower.includes(indicator))) {
    // Next week - no specific date
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    result.date = nextWeek.toISOString().split("T")[0];
  } else if (TIME_INDICATORS.later.some((indicator) => lower.includes(indicator))) {
    result.date = new Date().toISOString().split("T")[0];
  }

  return result;
}

/**
 * Get default day (today's day of week)
 */
export function getDefaultDay(): string {
  const days = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
  ];
  return days[new Date().getDay()];
}

/**
 * Check if input contains time indicators
 */
export function hasTimeReference(input: string): boolean {
  const lower = input.toLowerCase();
  return (
    Object.values(TIME_INDICATORS).some((indicators) =>
      indicators.some((indicator) => lower.includes(indicator))
    ) ||
    Object.values(DAYS_OF_WEEK).some((variants) =>
      variants.some((variant) => lower.includes(variant))
    )
  );
}
