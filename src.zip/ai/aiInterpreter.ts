/**
 * AI Interpreter - Rule-Based Only
 * Pure logic, deterministic output, NO OpenAI calls
 */

import type { AIIntent, TaskPayload, MealPayload, ShoppingPayload, ReminderPayload } from "./schemas/intentSchema";
import { isCleaningIntent } from "./patterns/cleaning";
import { isCookingIntent, extractMealType, extractMealName } from "./patterns/cooking";
import { isShoppingIntent, extractShoppingItems, extractShoppingCategory } from "./patterns/shopping";
import { extractTimeReference, getDefaultDay, hasTimeReference } from "./patterns/time";
import { isAmbiguous, isUrgent, extractTitle, TASK_KEYWORDS } from "./patterns/general";
import { normalizeText, detectAmbiguity, scoreIntentMatches, calculateConfidence } from "./aiUtils";

/**
 * Main interpreter function
 * Receives raw text and returns structured AIIntent
 */
export async function interpretInput(rawInput: string, context?: string): Promise<AIIntent> {
  const input = normalizeText(rawInput);
  
  if (!input || input.length === 0) {
    return {
      type: "unknown",
      confidence: 0,
      raw: rawInput,
      followUpQuestion: "I didn't catch that. Could you please tell me what you need?",
    };
  }

  // Combine with context if provided
  const fullInput = context ? `${context}\n${input}` : input;

  // Step 1: Check for ambiguity
  const ambiguity = detectAmbiguity(fullInput);
  if (ambiguity.isAmbiguous && ambiguity.ambiguityScore > 0.5) {
    return {
      type: "clarification",
      confidence: 0.4,
      raw: rawInput,
      followUpQuestion: "I'm not entirely sure what you need. Could you be more specific?",
    };
  }

  // Step 2: Run pattern matching for each intent type
  const matches = {
    task: matchTaskIntent(fullInput),
    meal: matchMealIntent(fullInput),
    shopping: matchShoppingIntent(fullInput),
    reminder: matchReminderIntent(fullInput),
  };

  // Step 3: Find the best match
  const bestMatch = findBestMatch(matches);

  // Step 4: If confidence is too low, return clarification
  if (bestMatch.confidence < 0.5) {
    return {
      type: "clarification",
      confidence: bestMatch.confidence,
      raw: rawInput,
      followUpQuestion: generateClarificationQuestion(matches),
    };
  }

  // Step 5: Return the best match
  return bestMatch.intent;
}

/**
 * Match task intent
 */
function matchTaskIntent(input: string): { intent: AIIntent | null; confidence: number } {
  const lower = input.toLowerCase();
  
  // Check for cleaning tasks
  if (isCleaningIntent(input)) {
    const timeRef = extractTimeReference(input);
    const title = extractTitle(input, "task");
    const payload: TaskPayload = {
      title,
      category: "cleaning",
      dueDate: timeRef.date,
      priority: isUrgent(input) ? "high" : "medium",
    };
    return {
      intent: {
        type: "task",
        confidence: 0.85,
        raw: input,
        payload,
      },
      confidence: 0.85,
    };
  }

  // Check for general task keywords
  const taskScore = scoreIntentMatches(input, TASK_KEYWORDS);
  if (taskScore > 0.3) {
    const timeRef = extractTimeReference(input);
    const title = extractTitle(input, "task");
    
    // Determine category
    let category: TaskPayload["category"] = "other";
    if (lower.includes("kid") || lower.includes("child") || lower.includes("school")) {
      category = "kids";
    } else if (lower.includes("buy") || lower.includes("get") || lower.includes("pick up")) {
      category = "errands";
    } else if (lower.includes("fix") || lower.includes("repair") || lower.includes("maintenance")) {
      category = "home-maintenance";
    }

    const payload: TaskPayload = {
      title,
      category,
      dueDate: timeRef.date,
      priority: isUrgent(input) ? "high" : "medium",
    };

    const confidence = calculateConfidence(taskScore, 0, hasTimeReference(input));
    return {
      intent: {
        type: "task",
        confidence,
        raw: input,
        payload,
      },
      confidence,
    };
  }

  return { intent: null, confidence: 0 };
}

/**
 * Match meal intent
 */
function matchMealIntent(input: string): { intent: AIIntent | null; confidence: number } {
  if (!isCookingIntent(input)) {
    return { intent: null, confidence: 0 };
  }

  const timeRef = extractTimeReference(input);
  const mealType = extractMealType(input);
  const name = extractMealName(input);
  const day = timeRef.day || getDefaultDay();

  const payload: MealPayload = {
    name,
    mealType,
    day,
  };

  return {
    intent: {
      type: "meal",
      confidence: 0.9,
      raw: input,
      payload,
    },
    confidence: 0.9,
  };
}

/**
 * Match shopping intent
 */
function matchShoppingIntent(input: string): { intent: AIIntent | null; confidence: number } {
  if (!isShoppingIntent(input)) {
    return { intent: null, confidence: 0 };
  }

  const items = extractShoppingItems(input);
  if (items.length === 0) {
    return { intent: null, confidence: 0 };
  }

  const category = items.length > 0 ? extractShoppingCategory(items[0]) : "other";
  const payload: ShoppingPayload = {
    items,
    category,
  };

  return {
    intent: {
      type: "shopping",
      confidence: 0.9,
      raw: input,
      payload,
    },
    confidence: 0.9,
  };
}

/**
 * Match reminder intent
 */
function matchReminderIntent(input: string): { intent: AIIntent | null; confidence: number } {
  const lower = input.toLowerCase();
  const reminderKeywords = ["remind", "reminder", "remember", "don't forget"];
  
  if (!reminderKeywords.some((kw) => lower.includes(kw))) {
    return { intent: null, confidence: 0 };
  }

  const timeRef = extractTimeReference(input);
  const title = extractTitle(input, "reminder");
  
  const payload: ReminderPayload = {
    title,
    time: timeRef.time,
    date: timeRef.date,
  };

  return {
    intent: {
      type: "reminder",
      confidence: 0.8,
      raw: input,
      payload,
    },
    confidence: 0.8,
  };
}

/**
 * Find the best match from all intent matches
 */
function findBestMatch(matches: {
  task: { intent: AIIntent | null; confidence: number };
  meal: { intent: AIIntent | null; confidence: number };
  shopping: { intent: AIIntent | null; confidence: number };
  reminder: { intent: AIIntent | null; confidence: number };
}): { intent: AIIntent; confidence: number } {
  const allMatches = [
    matches.task,
    matches.meal,
    matches.shopping,
    matches.reminder,
  ].filter((m) => m.intent !== null);

  if (allMatches.length === 0) {
    return {
      intent: {
        type: "unknown",
        confidence: 0,
        raw: "",
        followUpQuestion: "I'm not sure what you need. Could you rephrase?",
      },
      confidence: 0,
    };
  }

  // Sort by confidence
  allMatches.sort((a, b) => b.confidence - a.confidence);

  // If top two are close, return clarification
  if (allMatches.length > 1 && allMatches[0].confidence - allMatches[1].confidence < 0.2) {
    return {
      intent: {
        type: "clarification",
        confidence: (allMatches[0].confidence + allMatches[1].confidence) / 2,
        raw: "",
        followUpQuestion: generateClarificationQuestion(matches),
      },
      confidence: (allMatches[0].confidence + allMatches[1].confidence) / 2,
    };
  }

  return {
    intent: allMatches[0].intent!,
    confidence: allMatches[0].confidence,
  };
}

/**
 * Generate clarification question based on matches
 */
function generateClarificationQuestion(matches: {
  task: { intent: AIIntent | null; confidence: number };
  meal: { intent: AIIntent | null; confidence: number };
  shopping: { intent: AIIntent | null; confidence: number };
  reminder: { intent: AIIntent | null; confidence: number };
}): string {
  const possibleTypes: string[] = [];

  if (matches.task.confidence > 0.3) possibleTypes.push("a task");
  if (matches.meal.confidence > 0.3) possibleTypes.push("a meal");
  if (matches.shopping.confidence > 0.3) possibleTypes.push("a shopping item");
  if (matches.reminder.confidence > 0.3) possibleTypes.push("a reminder");

  if (possibleTypes.length === 0) {
    return "I'm not sure what you need. Are you asking about a task, meal, shopping item, or reminder?";
  }

  if (possibleTypes.length === 1) {
    return `Are you asking about ${possibleTypes[0]}?`;
  }

  const lastType = possibleTypes.pop();
  return `Are you asking about ${possibleTypes.join(", ")}, or ${lastType}?`;
}
