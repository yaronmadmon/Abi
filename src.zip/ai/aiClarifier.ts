/**
 * AI Clarifier
 * Generates follow-up questions when interpreter is unsure
 * NEVER guesses - only asks questions
 */

import type { AIIntent } from "./schemas/intentSchema";

/**
 * Generate clarification question based on partial intent
 */
export function generateClarification(partialIntent: AIIntent): AIIntent {
  // If already a clarification, return as-is
  if (partialIntent.type === "clarification") {
    return partialIntent;
  }

  // If unknown, ask generic question
  if (partialIntent.type === "unknown") {
    return {
      type: "clarification",
      confidence: 0.3,
      raw: partialIntent.raw,
      followUpQuestion:
        "I'm not sure what you need. Are you asking about:\n• A task to do\n• A meal to plan\n• Something to buy\n• A reminder to set",
    };
  }

  // Generate specific clarification based on intent type
  const question = generateSpecificQuestion(partialIntent);
  
  return {
    type: "clarification",
    confidence: partialIntent.confidence,
    raw: partialIntent.raw,
    followUpQuestion: question,
  };
}

/**
 * Generate specific clarification question
 */
function generateSpecificQuestion(intent: AIIntent): string {
  switch (intent.type) {
    case "task":
      if (!intent.payload?.title || intent.payload.title === "New item") {
        return "What task would you like to add? Please be specific.";
      }
      if (!intent.payload?.category || intent.payload.category === "other") {
        return `I understand you want to add "${intent.payload.title}". What category should this be? (cleaning, errands, kids, home maintenance, or other)`;
      }
      return `Just to confirm, you want to add the task "${intent.payload.title}"?`;

    case "meal":
      if (!intent.payload?.name || intent.payload.name === "New meal") {
        return "What meal would you like to plan? Please specify the meal name.";
      }
      if (!intent.payload?.mealType) {
        return `I see you want to plan "${intent.payload.name}". Is this for breakfast, lunch, or dinner?`;
      }
      return `Just to confirm, you want to add "${intent.payload.name}" as a ${intent.payload.mealType}?`;

    case "shopping":
      if (!intent.payload?.items || intent.payload.items.length === 0) {
        return "What items would you like to add to your shopping list?";
      }
      if (intent.payload.items.length === 1 && intent.payload.items[0] === "New item") {
        return "What specific item would you like to add to your shopping list?";
      }
      return `I found these items: ${intent.payload.items.join(", ")}. Is this correct?`;

    case "reminder":
      if (!intent.payload?.title || intent.payload.title === "New item") {
        return "What would you like to be reminded about?";
      }
      if (!intent.payload?.date && !intent.payload?.time) {
        return `I understand you want a reminder for "${intent.payload.title}". When should I remind you?`;
      }
      return `Just to confirm, you want a reminder for "${intent.payload.title}"?`;

    default:
      return "Could you provide more details about what you need?";
  }
}

/**
 * Check if intent needs clarification
 */
export function needsClarification(intent: AIIntent): boolean {
  // Low confidence always needs clarification
  if (intent.confidence < 0.5) {
    return true;
  }

  // Check payload completeness
  switch (intent.type) {
    case "task":
      return !intent.payload?.title || intent.payload.title === "New item";

    case "meal":
      return !intent.payload?.name || intent.payload.name === "New meal";

    case "shopping":
      return !intent.payload?.items || intent.payload.items.length === 0;

    case "reminder":
      return !intent.payload?.title || intent.payload.title === "New item";

    case "clarification":
      return true;

    case "unknown":
      return true;

    default:
      return false;
  }
}
