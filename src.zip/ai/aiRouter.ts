/**
 * AI Router
 * Routes interpreted intents to appropriate module handlers
 * Clean separation between AI understanding and app behavior
 */

import type { AIIntent, TaskPayload, MealPayload, ShoppingPayload, ReminderPayload } from "./schemas/intentSchema";
import type { ModuleRoute, RouterResult } from "./schemas/routerSchema";
import { tasksHandler } from "./handlers/tasksHandler";
import { mealsHandler } from "./handlers/mealsHandler";
import { shoppingHandler } from "./handlers/shoppingHandler";
import { remindersHandler } from "./handlers/remindersHandler";

/**
 * Route intent to appropriate module
 * Returns routing result with action and payload
 */
export async function routeIntent(intent: AIIntent): Promise<RouterResult> {
  switch (intent.type) {
    case "task":
      return routeTask(intent.payload as TaskPayload);

    case "meal":
      return routeMeal(intent.payload as MealPayload);

    case "shopping":
      return routeShopping(intent.payload as ShoppingPayload);

    case "reminder":
      return routeReminder(intent.payload as ReminderPayload);

    case "clarification":
      return {
        success: true,
        route: "none",
        message: "Clarification needed",
        payload: {
          question: intent.followUpQuestion,
        },
      };

    case "unknown":
      return {
        success: false,
        route: "none",
        error: intent.followUpQuestion || "Could not understand the request",
      };

    default:
      return {
        success: false,
        route: "none",
        error: "Unknown intent type",
      };
  }
}

/**
 * Route task intent
 */
async function routeTask(payload: TaskPayload): Promise<RouterResult> {
  if (!payload || !payload.title) {
    return {
      success: false,
      route: "tasks",
      error: "Task title is required",
    };
  }

  try {
    await tasksHandler.create(payload);
    return {
      success: true,
      route: "tasks",
      message: `Task "${payload.title}" added successfully`,
      payload,
    };
  } catch (error) {
    return {
      success: false,
      route: "tasks",
      error: error instanceof Error ? error.message : "Failed to create task",
    };
  }
}

/**
 * Route meal intent
 */
async function routeMeal(payload: MealPayload): Promise<RouterResult> {
  if (!payload || !payload.name) {
    return {
      success: false,
      route: "meals",
      error: "Meal name is required",
    };
  }

  try {
    await mealsHandler.create(payload);
    return {
      success: true,
      route: "meals",
      message: `Meal "${payload.name}" added successfully`,
      payload,
    };
  } catch (error) {
    return {
      success: false,
      route: "meals",
      error: error instanceof Error ? error.message : "Failed to create meal",
    };
  }
}

/**
 * Route shopping intent
 */
async function routeShopping(payload: ShoppingPayload): Promise<RouterResult> {
  if (!payload || !payload.items || payload.items.length === 0) {
    return {
      success: false,
      route: "shopping",
      error: "Shopping items are required",
    };
  }

  try {
    await shoppingHandler.create(payload);
    return {
      success: true,
      route: "shopping",
      message: `${payload.items.length} item(s) added to shopping list`,
      payload,
    };
  } catch (error) {
    return {
      success: false,
      route: "shopping",
      error: error instanceof Error ? error.message : "Failed to add shopping items",
    };
  }
}

/**
 * Route reminder intent
 */
async function routeReminder(payload: ReminderPayload): Promise<RouterResult> {
  if (!payload || !payload.title) {
    return {
      success: false,
      route: "reminders",
      error: "Reminder title is required",
    };
  }

  try {
    // For now, reminders are treated as tasks
    await remindersHandler.create(payload);
    return {
      success: true,
      route: "reminders",
      message: `Reminder "${payload.title}" added successfully`,
      payload,
    };
  } catch (error) {
    return {
      success: false,
      route: "reminders",
      error: error instanceof Error ? error.message : "Failed to create reminder",
    };
  }
}
