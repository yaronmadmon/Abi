/**
 * Tasks Module Handler
 * Adapter for tasks module - wraps existing module logic
 */

import type { TaskPayload } from "../schemas/intentSchema";
import type { Task } from "@/types/home";

export interface ModuleHandler {
  create(data: any): Promise<void>;
}

class TasksHandler implements ModuleHandler {
  async create(payload: TaskPayload): Promise<void> {
    // Check if localStorage is available (client-side only)
    if (typeof window === 'undefined' || !window.localStorage) {
      throw new Error('localStorage is not available');
    }

    // Load existing tasks
    const stored = localStorage.getItem("tasks");
    const tasks: Task[] = stored ? JSON.parse(stored) : [];

    // Create new task
    const task: Task = {
      id: Date.now().toString(),
      title: payload.title,
      category: payload.category || "other",
      dueDate: payload.dueDate,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    // Save tasks
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }
}

export const tasksHandler = new TasksHandler();
