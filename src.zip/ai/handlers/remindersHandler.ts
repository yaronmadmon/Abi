/**
 * Reminders Module Handler
 * Adapter for reminders module - wraps existing module logic
 * For now, reminders are stored as tasks
 */

import type { ReminderPayload } from "../schemas/intentSchema";
import type { Task } from "@/types/home";

export interface ModuleHandler {
  create(data: any): Promise<void>;
}

class RemindersHandler implements ModuleHandler {
  async create(payload: ReminderPayload): Promise<void> {
    // Check if localStorage is available (client-side only)
    if (typeof window === 'undefined' || !window.localStorage) {
      throw new Error('localStorage is not available');
    }

    // Load existing tasks (reminders are stored as tasks for now)
    const stored = localStorage.getItem("tasks");
    const tasks: Task[] = stored ? JSON.parse(stored) : [];

    // Create new task (reminder)
    const task: Task = {
      id: Date.now().toString(),
      title: payload.title,
      category: "other",
      dueDate: payload.date,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    // Save tasks
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }
}

export const remindersHandler = new RemindersHandler();
