/**
 * AI Module - Main exports
 * Central export point for the AI foundation
 */

// Schemas
export * from './schemas/intentSchema'
export * from './schemas/routerSchema'

// Core AI functions
export { interpretInput } from './aiInterpreter'
export { generateClarification, needsClarification } from './aiClarifier'
export { routeIntent } from './aiRouter'

// Utils
export * from './aiUtils'
