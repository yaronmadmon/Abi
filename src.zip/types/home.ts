export interface HomeProfile {
  numberOfPeople: number
  hasPets: boolean
  homeType: 'apartment' | 'house'
  topStruggles: string[]
  dietaryPreferences: string[]
  weeklyRoutine?: string
}

export interface Task {
  id: string
  title: string
  category: 'cleaning' | 'errands' | 'kids' | 'home-maintenance' | 'other'
  dueDate?: string
  completed: boolean
  createdAt: string
}

export interface Meal {
  id: string
  name: string
  day: string // 'monday' | 'tuesday' | etc.
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack'
  createdAt: string
}

export interface ShoppingItem {
  id: string
  name: string
  category: 'produce' | 'dairy' | 'meat' | 'cleaning' | 'pantry' | 'other'
  completed: boolean
  createdAt: string
}

export type AIInputType = 'task' | 'meal' | 'shopping' | 'reminder' | 'unknown'

export interface AIClassification {
  type: AIInputType
  data: {
    title?: string
    category?: string
    day?: string
    mealType?: string
  }
  needsClarification?: boolean
  clarificationQuestion?: string
}
