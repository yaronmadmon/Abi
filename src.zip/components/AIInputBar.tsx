'use client'

import { useState } from 'react'
import type { AIIntent } from '@/ai/schemas/intentSchema'
import { routeIntent } from '@/ai/aiRouter'

interface AIInputBarProps {
  onIntent: (action: string, payload: any) => void
  onError?: (error: string) => void
}

export default function AIInputBar({ onIntent, onError }: AIInputBarProps) {
  const [input, setInput] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [clarification, setClarification] = useState<{
    question: string
    context: string
  } | null>(null)
  const [conversationContext, setConversationContext] = useState<string>('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isProcessing) return

    const currentInput = input.trim()
    setIsProcessing(true)

    try {
      // Step 1: Send text to /api/ai/classify
      // Build context if we're in a clarification flow
      const context = clarification
        ? `${clarification.context}\nUser clarification: ${currentInput}`
        : conversationContext

      const response = await fetch('/api/ai/classify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          input: currentInput,
          context: context || undefined
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to classify input')
      }

      const data = await response.json()
      
      // Handle error response
      if (data.error) {
        onError?.(data.error)
        setInput('')
        setIsProcessing(false)
        return
      }

      // Extract intent from response (API returns intent directly or wrapped)
      const intent: AIIntent = data.intent || data

      // Step 2: If clarification, show follow-up question
      if (intent.type === 'clarification') {
        setClarification({
          question: intent.followUpQuestion || 'Could you clarify?',
          context: conversationContext || currentInput,
        })
        setConversationContext(conversationContext ? `${conversationContext}\n${currentInput}` : currentInput)
        setInput('')
        setIsProcessing(false)
        return
      }

      // Step 3: If unknown, show error or clarification
      if (intent.type === 'unknown') {
        if (intent.followUpQuestion) {
          setClarification({
            question: intent.followUpQuestion,
            context: conversationContext || currentInput,
          })
          setConversationContext(conversationContext ? `${conversationContext}\n${currentInput}` : currentInput)
        } else {
          onError?.('Could not understand the request. Please try rephrasing.')
        }
        setInput('')
        setIsProcessing(false)
        return
      }

      // Step 4: Route intent to appropriate module
      const routerResult = await routeIntent(intent)

      if (routerResult.success) {
        // Clear clarification if we successfully processed
        setClarification(null)
        setConversationContext('')
        setInput('')
        
        // Call the handler with route and payload
        onIntent(routerResult.route, routerResult.payload)
      } else {
        onError?.(routerResult.error || 'Failed to process request')
      }
    } catch (error) {
      console.error('Failed to classify input:', error)
      onError?.('Sorry, something went wrong. Please try again.')
    } finally {
      setIsProcessing(false)
    }
  }

  const handleClearClarification = () => {
    setClarification(null)
    setConversationContext('')
  }

  return (
    <div className="mb-6">
      {clarification && (
        <div className="glass-card p-4 mb-4 bg-blue-50/50 border-blue-200">
          <div className="flex items-start gap-3">
            <div className="flex-1">
              <p className="text-sm font-medium text-blue-900 mb-1">
                Need clarification:
              </p>
              <p className="text-sm text-blue-700 whitespace-pre-line">
                {clarification.question}
              </p>
            </div>
            <button
              onClick={handleClearClarification}
              className="text-blue-400 hover:text-blue-600 text-xl"
              type="button"
            >
              ×
            </button>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="glass-card p-4 flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              clarification
                ? "Answer the question above..."
                : "Tell me what you need... (e.g., 'Add a reminder to switch laundry later')"
            }
            className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/50"
            disabled={isProcessing}
          />
          <button
            type="submit"
            disabled={!input.trim() || isProcessing}
            className="btn-primary px-6 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? '...' : '→'}
          </button>
        </div>
      </form>
    </div>
  )
}
