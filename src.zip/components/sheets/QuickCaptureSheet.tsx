'use client'

import { useEffect } from 'react'
import AIInputBar from '../AIInputBar'

interface QuickCaptureSheetProps {
  type: 'thought' | 'task' | 'reminder' | 'appointment' | 'note'
  isOpen: boolean
  onClose: () => void
}

export default function QuickCaptureSheet({ type, isOpen, onClose }: QuickCaptureSheetProps) {
  // Lock body scroll when sheet is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [isOpen])

  if (!isOpen) return null

  const handleIntent = async (route: string, payload: any) => {
    // Route will be handled automatically by the AI router via AIInputBar
    // Close sheet after successful capture
    setTimeout(() => {
      onClose()
    }, 300)
  }

  const labels = {
    thought: 'What\'s on your mind?',
    task: 'What needs to be done?',
    reminder: 'What should I remind you about?',
    appointment: 'What\'s the appointment?',
    note: 'What would you like to note?',
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-end" style={{ animation: 'fadeIn 200ms ease-in-out' }}>
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/20 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Sheet */}
      <div className="relative w-full bg-white rounded-t-3xl shadow-soft-lg max-h-[80vh] flex flex-col" style={{ animation: 'slideUp 240ms cubic-bezier(0.16, 1, 0.3, 1)' }}>
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-12 h-1 bg-gray-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900">{labels[type]}</h2>
          <p className="text-sm text-gray-500 mt-1">AI will route this to the right place</p>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <AIInputBar onIntent={handleIntent} />
        </div>
      </div>
    </div>
  )
}
