'use client'

import { useState } from 'react'
import QuickCaptureSheet from '../sheets/QuickCaptureSheet'

type CaptureType = 'thought' | 'task' | 'reminder' | 'appointment' | 'note'

export default function QuickCaptureRow() {
  const [openSheet, setOpenSheet] = useState<CaptureType | null>(null)

  const captureOptions: { type: CaptureType; label: string; icon: string }[] = [
    { type: 'thought', label: 'Thought', icon: '💭' },
    { type: 'task', label: 'Task', icon: '✓' },
    { type: 'reminder', label: 'Reminder', icon: '⏰' },
    { type: 'appointment', label: 'Appointment', icon: '📅' },
    { type: 'note', label: 'Note', icon: '📝' },
  ]

  return (
    <>
      <div className="glass-card p-4 mb-4">
        <div className="flex items-center justify-between gap-2 overflow-x-auto scrollbar-hide">
          {captureOptions.map((option) => (
            <button
              key={option.type}
              onClick={() => setOpenSheet(option.type)}
              className="flex flex-col items-center justify-center gap-2 min-w-[70px] p-3 rounded-xl bg-white/60 hover:bg-white/80 active:scale-95 transition-all duration-200"
            >
              <span className="text-2xl">{option.icon}</span>
              <span className="text-xs font-medium text-gray-700">{option.label}</span>
            </button>
          ))}
        </div>
      </div>

      {openSheet && (
        <QuickCaptureSheet
          type={openSheet}
          isOpen={!!openSheet}
          onClose={() => setOpenSheet(null)}
        />
      )}
    </>
  )
}
