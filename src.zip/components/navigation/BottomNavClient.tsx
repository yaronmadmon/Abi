'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'

interface NavItem {
  href: string
  label: string
  icon: string
}

const navItems: NavItem[] = [
  { href: '/today', label: 'Today', icon: '📅' },
  { href: '/home', label: 'Home', icon: '🏠' },
  { href: '/kitchen', label: 'Kitchen', icon: '👨‍🍳' },
  { href: '/finance', label: 'Finance', icon: '💳' },
  { href: '/people', label: 'People', icon: '👥' },
  { href: '/office', label: 'Office', icon: '📁' },
]

export default function BottomNavClient() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-200/50 shadow-soft-lg z-50" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
      <div className="flex items-center justify-around h-16 max-w-2xl mx-auto px-4">
        {navItems.map((item) => {
          const isActive = pathname === item.href || (pathname?.startsWith(item.href + '/') && item.href !== '/today')
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-all duration-200 ${
                isActive
                  ? 'text-blue-600 scale-105'
                  : 'text-gray-500 hover:text-gray-700 active:scale-95'
              }`}
            >
              <span className="text-2xl mb-1">{item.icon}</span>
              <span className={`text-xs font-medium ${isActive ? 'font-semibold' : ''}`}>
                {item.label}
              </span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
