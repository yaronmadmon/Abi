/**
 * Search Module
 */

export { SemanticSearch } from './SemanticSearch';
