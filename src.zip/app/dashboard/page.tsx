'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import type { HomeProfile } from '@/types/home'

export default function DashboardPage() {
  const [profile, setProfile] = useState<HomeProfile | null>(null)

  useEffect(() => {
    const stored = localStorage.getItem('homeProfile')
    if (stored) {
      setProfile(JSON.parse(stored))
    }
  }, [])

  const modules = [
    {
      title: 'Tasks',
      description: 'Manage your daily tasks',
      href: '/dashboard/tasks',
      icon: '✓',
      color: 'from-blue-500 to-blue-600',
    },
    {
      title: 'Meals',
      description: 'Plan your weekly meals',
      href: '/dashboard/meals',
      icon: '🍽️',
      color: 'from-green-500 to-green-600',
    },
    {
      title: 'Shopping',
      description: 'Your shopping list',
      href: '/dashboard/shopping',
      icon: '🛒',
      color: 'from-orange-500 to-orange-600',
    },
    {
      title: 'Weekly View',
      description: 'See your week at a glance',
      href: '/dashboard/weekly',
      icon: '📅',
      color: 'from-purple-500 to-purple-600',
    },
  ]

  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Welcome Home
          </h1>
          <p className="text-gray-600">
            {profile?.numberOfPeople
              ? `Managing a ${profile.homeType} for ${profile.numberOfPeople} ${profile.numberOfPeople === 1 ? 'person' : 'people'}`
              : 'Your home management hub'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {modules.map((module) => (
            <Link
              key={module.title}
              href={module.href}
              className="glass-card p-6 hover:shadow-soft-lg transition-all duration-200 active:scale-95"
            >
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${module.color} flex items-center justify-center text-3xl mb-4 shadow-soft`}>
                {module.icon}
              </div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">
                {module.title}
              </h2>
              <p className="text-gray-600">{module.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
