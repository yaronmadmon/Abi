'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import type { Task } from '@/types/home'
import AIInputBar from '@/components/AIInputBar'

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTaskTitle, setNewTaskTitle] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<Task['category']>('other')
  const [showAddForm, setShowAddForm] = useState(false)

  useEffect(() => {
    loadTasks()
  }, [])

  const loadTasks = () => {
    const stored = localStorage.getItem('tasks')
    if (stored) {
      setTasks(JSON.parse(stored))
    }
  }

  const saveTasks = (newTasks: Task[]) => {
    localStorage.setItem('tasks', JSON.stringify(newTasks))
    setTasks(newTasks)
  }

  const addTask = (title: string, category: Task['category'] = 'other', dueDate?: string) => {
    const task: Task = {
      id: Date.now().toString(),
      title,
      category,
      dueDate,
      completed: false,
      createdAt: new Date().toISOString(),
    }
    saveTasks([...tasks, task])
    setNewTaskTitle('')
    setShowAddForm(false)
  }

  const toggleTask = (id: string) => {
    saveTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    )
  }

  const deleteTask = (id: string) => {
    saveTasks(tasks.filter((task) => task.id !== id))
  }

  const handleAIIntent = (route: string, payload: any) => {
    if (route === 'tasks') {
      const category = (payload.category || 'other') as Task['category']
      addTask(payload.title || 'New task', category, payload.dueDate)
      // Reload tasks to show the new one
      loadTasks()
    }
  }

  const categories: Task['category'][] = [
    'cleaning',
    'errands',
    'kids',
    'home-maintenance',
    'other',
  ]

  const groupedTasks = tasks.reduce((acc, task) => {
    const date = task.dueDate
      ? new Date(task.dueDate).toLocaleDateString()
      : 'No date'
    if (!acc[date]) acc[date] = []
    acc[date].push(task)
    return acc
  }, {} as Record<string, Task[]>)

  return (
    <div className="min-h-screen p-6 pb-24">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <Link href="/dashboard" className="text-gray-500 hover:text-gray-700">
            ← Back
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Tasks</h1>
          <div className="w-12"></div>
        </div>

        <AIInputBar onIntent={handleAIIntent} />

        {!showAddForm ? (
          <button
            onClick={() => setShowAddForm(true)}
            className="btn-secondary w-full mb-6"
          >
            + Add Task Manually
          </button>
        ) : (
          <div className="glass-card p-4 mb-6">
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="Task title"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 mb-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              onKeyPress={(e) => {
                if (e.key === 'Enter' && newTaskTitle.trim()) {
                  addTask(newTaskTitle.trim(), selectedCategory)
                }
              }}
            />
            <select
              value={selectedCategory}
              onChange={(e) =>
                setSelectedCategory(e.target.value as Task['category'])
              }
              className="w-full px-4 py-3 rounded-xl border border-gray-200 mb-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat.replace('-', ' ').replace(/\b\w/g, (l) => l.toUpperCase())}
                </option>
              ))}
            </select>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  if (newTaskTitle.trim()) {
                    addTask(newTaskTitle.trim(), selectedCategory)
                  }
                }}
                className="btn-primary flex-1"
              >
                Add
              </button>
              <button
                onClick={() => {
                  setShowAddForm(false)
                  setNewTaskTitle('')
                }}
                className="btn-secondary flex-1"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {Object.keys(groupedTasks).length === 0 ? (
          <div className="glass-card p-8 text-center text-gray-500">
            No tasks yet. Add one to get started!
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedTasks).map(([date, dateTasks]) => (
              <div key={date} className="glass-card p-4">
                <h2 className="font-semibold text-gray-700 mb-3">{date}</h2>
                <div className="space-y-2">
                  {dateTasks.map((task) => (
                    <div
                      key={task.id}
                      className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/50 transition-colors"
                    >
                      <input
                        type="checkbox"
                        checked={task.completed}
                        onChange={() => toggleTask(task.id)}
                        className="w-5 h-5 rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                      />
                      <div className="flex-1">
                        <p
                          className={`${
                            task.completed
                              ? 'line-through text-gray-400'
                              : 'text-gray-900'
                          }`}
                        >
                          {task.title}
                        </p>
                        <span className="text-xs text-gray-500">
                          {task.category.replace('-', ' ')}
                        </span>
                      </div>
                      <button
                        onClick={() => deleteTask(task.id)}
                        className="text-red-400 hover:text-red-600"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
