'use client'

import { useState } from 'react'
import AIFocusHeader from '@/components/today/AIFocusHeader'
import NowCard from '@/components/today/NowCard'
import QuickCaptureRow from '@/components/today/QuickCaptureRow'
import PlanSomethingSheet from '@/components/sheets/PlanSomethingSheet'
import CareCard from '@/components/today/CareCard'
import GlanceBar from '@/components/today/GlanceBar'

export default function TodayPage() {
  const [showPlanSheet, setShowPlanSheet] = useState(false)

  return (
    <div className="min-h-screen p-6 page-with-bottom-nav bg-gradient-to-br from-gray-50 via-white to-blue-50/30">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Today</h1>
          <p className="text-sm text-gray-500">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {/* 1. AI Focus Header */}
        <AIFocusHeader />

        {/* 2. Now Card */}
        <NowCard />

        {/* 3. Quick Capture Row */}
        <QuickCaptureRow />

        {/* 4. Plan Something Card */}
        <div className="glass-card p-5 mb-4">
          <button
            onClick={() => setShowPlanSheet(true)}
            className="w-full flex items-center justify-between text-left group"
          >
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-1 group-hover:text-blue-600 transition-colors">
                Plan Something
              </h3>
              <p className="text-sm text-gray-500">What would you like to plan?</p>
            </div>
            <span className="text-2xl group-hover:scale-110 transition-transform">✨</span>
          </button>
        </div>

        {/* 5. Care / Reset Card */}
        <CareCard />

        {/* 6. Glance Bar */}
        <GlanceBar />

        {/* Plan Something Sheet */}
        <PlanSomethingSheet
          isOpen={showPlanSheet}
          onClose={() => setShowPlanSheet(false)}
        />
      </div>
    </div>
  )
}
