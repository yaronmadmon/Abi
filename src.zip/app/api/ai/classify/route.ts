import { NextRequest, NextResponse } from 'next/server'
import { interpretInput } from '@/ai/aiInterpreter'
import { needsClarification, generateClarification } from '@/ai/aiClarifier'
import type { AIIntent } from '@/ai/schemas/intentSchema'

/**
 * AI Classification Endpoint
 * 
 * Input: raw user text
 * Output: structured AIIntent
 * 
 * No side effects - pure interpretation only
 * Does not route - only interprets
 */
export async function POST(request: NextRequest) {
  try {
    const { input, context } = await request.json()

    if (!input || typeof input !== 'string') {
      return NextResponse.json(
        { error: 'Invalid input. Expected a string.' },
        { status: 400 }
      )
    }

    // Step 1: Interpret input
    const intent: AIIntent = await interpretInput(input, context)

    // Step 2: Check if clarification is needed
    if (needsClarification(intent) && intent.type !== 'clarification' && intent.type !== 'unknown') {
      const clarification = generateClarification(intent)
      return NextResponse.json(clarification)
    }

    // Step 3: Return structured intent (shape: { intent: AIIntent })
    return NextResponse.json({ intent })
  } catch (error) {
    console.error('AI classification error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to classify input',
        intent: {
          type: 'unknown',
          confidence: 0,
          raw: '',
          followUpQuestion: 'Sorry, I encountered an error. Could you try rephrasing that?'
        } as AIIntent
      },
      { status: 500 }
    )
  }
}
