# Home Assistant Companion - Life OS

Premium "Home Assistant Companion" application foundation.

## Phase 0

This phase establishes the core foundation:
- Clean app shell with routing
- Unified data models
- Premium UI system
- AI abstraction layer (no execution)

## Development

```bash
npm install
npm run dev
```
