/**
 * Calendar Utilities
 * Conflict detection and reschedule suggestions
 */

import { Task, Event } from '@/models';
import { CalendarConflict, RescheduleSuggestion } from '@/types/tasks';

const MINIMUM_GAP_MINUTES = 30; // Minimum time between tasks/events

/**
 * Detect conflicts between tasks and events
 */
export function detectConflicts(
  task: Task,
  events: Event[],
  otherTasks: Task[] = []
): CalendarConflict[] {
  if (!task.dueDate) {
    return [];
  }

  const conflicts: CalendarConflict[] = [];
  const taskDate = new Date(task.dueDate);

  // Check against events
  events.forEach((event) => {
    const eventStart = new Date(event.startTime);
    const eventEnd = event.endTime ? new Date(event.endTime) : new Date(eventStart.getTime() + 60 * 60 * 1000);

    const conflict = detectTaskEventConflict(task, taskDate, event, eventStart, eventEnd);
    if (conflict) {
      conflicts.push(conflict);
    }
  });

  // Check against other tasks
  otherTasks.forEach((otherTask) => {
    if (otherTask.id === task.id || !otherTask.dueDate) {
      return;
    }

    const otherTaskDate = new Date(otherTask.dueDate);
    const conflict = detectTaskTaskConflict(task, taskDate, otherTask, otherTaskDate);
    if (conflict) {
      conflicts.push(conflict);
    }
  });

  return conflicts;
}

/**
 * Detect conflict between a task and an event
 */
function detectTaskEventConflict(
  task: Task,
  taskDate: Date,
  event: Event,
  eventStart: Date,
  eventEnd: Date
): CalendarConflict | null {
  // Check for overlap
  if (taskDate >= eventStart && taskDate < eventEnd) {
    return {
      taskId: task.id,
      eventId: event.id,
      conflictType: 'overlap',
      severity: 'high',
      suggestedReschedule: suggestRescheduleTime(taskDate, eventEnd),
    };
  }

  // Check if too close (within minimum gap)
  const gapMinutes = Math.abs((taskDate.getTime() - eventStart.getTime()) / (1000 * 60));
  if (gapMinutes < MINIMUM_GAP_MINUTES) {
    return {
      taskId: task.id,
      eventId: event.id,
      conflictType: 'too_close',
      severity: 'medium',
      suggestedReschedule: suggestRescheduleTime(taskDate, eventEnd),
    };
  }

  return null;
}

/**
 * Detect conflict between two tasks
 */
function detectTaskTaskConflict(
  task: Task,
  taskDate: Date,
  otherTask: Task,
  otherTaskDate: Date
): CalendarConflict | null {
  // Check if tasks are at the same time (within 15 minutes)
  const diffMinutes = Math.abs((taskDate.getTime() - otherTaskDate.getTime()) / (1000 * 60));
  
  if (diffMinutes < 15) {
    return {
      taskId: task.id,
      eventId: otherTask.id, // Using eventId field for other task ID
      conflictType: 'overlap',
      severity: 'high',
      suggestedReschedule: suggestRescheduleTime(taskDate, new Date(otherTaskDate.getTime() + 60 * 60 * 1000)),
    };
  }

  return null;
}

/**
 * Suggest a reschedule time (after the conflicting event/task)
 */
function suggestRescheduleTime(originalTime: Date, conflictEnd: Date): string {
  // Suggest time after conflict with minimum gap
  const suggestedTime = new Date(conflictEnd.getTime() + MINIMUM_GAP_MINUTES * 60 * 1000);
  return suggestedTime.toISOString();
}

/**
 * Generate reschedule suggestions for a task
 */
export function generateRescheduleSuggestions(
  task: Task,
  events: Event[],
  otherTasks: Task[] = []
): RescheduleSuggestion[] {
  if (!task.dueDate) {
    return [];
  }

  const suggestions: RescheduleSuggestion[] = [];
  const conflicts = detectConflicts(task, events, otherTasks);

  conflicts.forEach((conflict) => {
    if (conflict.suggestedReschedule) {
      suggestions.push({
        taskId: task.id,
        originalDate: task.dueDate!,
        suggestedDate: conflict.suggestedReschedule,
        reason: `Avoids conflict with ${conflict.conflictType === 'overlap' ? 'overlapping' : 'closely scheduled'} item`,
        confidence: conflict.severity === 'high' ? 0.9 : 0.7,
      });
    }
  });

  return suggestions;
}

/**
 * Find next available time slot
 */
export function findNextAvailableSlot(
  desiredTime: Date,
  events: Event[],
  tasks: Task[] = [],
  durationMinutes: number = 60
): Date {
  const slots: Date[] = [];
  
  // Collect all occupied slots
  events.forEach((event) => {
    slots.push(new Date(event.startTime));
    if (event.endTime) {
      slots.push(new Date(event.endTime));
    }
  });

  tasks.forEach((task) => {
    if (task.dueDate) {
      slots.push(new Date(task.dueDate));
    }
  });

  // Sort slots
  slots.sort((a, b) => a.getTime() - b.getTime());

  // Find next available slot
  let candidate = new Date(desiredTime);
  
  for (const slot of slots) {
    const gap = (slot.getTime() - candidate.getTime()) / (1000 * 60);
    if (gap >= durationMinutes + MINIMUM_GAP_MINUTES) {
      return candidate;
    }
    candidate = new Date(slot.getTime() + MINIMUM_GAP_MINUTES * 60 * 1000);
  }

  // If no conflicts found, use desired time
  return desiredTime;
}
