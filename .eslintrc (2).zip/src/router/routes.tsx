/**
 * Application Routes
 */

import { createBrowserRouter } from 'react-router-dom';
import { AppShell } from '@/ui/components';
import { Home, Today, Timeline, Me, HomeOps, Documents, Communication, Financial, SmartHome, Trust } from '@/pages';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <AppShell />,
    children: [
      {
        index: true,
        element: <Today />, // Today is the main entry point
      },
      {
        path: 'home',
        element: <Home />,
      },
      {
        path: 'today',
        element: <Today />,
      },
      {
        path: 'timeline',
        element: <Timeline />,
      },
      {
        path: 'me',
        element: <Me />,
      },
      {
        path: 'home-ops',
        element: <HomeOps />,
      },
      {
        path: 'documents',
        element: <Documents />,
      },
      {
        path: 'communication',
        element: <Communication />,
      },
      {
        path: 'financial',
        element: <Financial />,
      },
      {
        path: 'smart-home',
        element: <SmartHome />,
      },
      {
        path: 'trust',
        element: <Trust />,
      },
    ],
  },
]);
