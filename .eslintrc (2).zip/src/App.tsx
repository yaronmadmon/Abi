import { RouterProvider } from 'react-router-dom';
import { router } from './router/routes';
import { EmotionalContextProvider } from './context/EmotionalContext';
import { UndoProvider } from './context/UndoContext';
import '@/ui/global.css';

function App() {
  return (
    <EmotionalContextProvider>
      <UndoProvider>
        <RouterProvider router={router} />
      </UndoProvider>
    </EmotionalContextProvider>
  );
}

export default App;
