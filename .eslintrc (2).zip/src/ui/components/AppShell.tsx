/**
 * App Shell Component
 * Main layout container with navigation
 */

import { Outlet, Link, useLocation } from 'react-router-dom';
import { OfflineIndicator } from './OfflineIndicator';
import './AppShell.css';

const navigationItems = [
  { path: '/', label: 'Today', icon: '📅' },
  { path: '/home', label: 'Home', icon: '🏠' },
  { path: '/timeline', label: 'Timeline', icon: '⏱️' },
  { path: '/me', label: 'Me', icon: '👤' },
  { path: '/home-ops', label: 'Home Ops', icon: '⚙️' },
  { path: '/documents', label: 'Documents', icon: '📄' },
  { path: '/communication', label: 'Communication', icon: '✉️' },
  { path: '/financial', label: 'Financial', icon: '💳' },
  { path: '/smart-home', label: 'Smart Home', icon: '🏠' },
  { path: '/trust', label: 'Trust', icon: '🔒' },
];

export function AppShell() {
  const location = useLocation();

  return (
    <div className="app-shell">
      <OfflineIndicator className="app-shell__offline" />
      <main className="app-shell__main">
        <Outlet />
      </main>
      
      <nav className="app-shell__nav" aria-label="Main navigation">
        {navigationItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`app-shell__nav-item ${isActive ? 'app-shell__nav-item--active' : ''}`}
              aria-current={isActive ? 'page' : undefined}
            >
              <span className="app-shell__nav-icon" aria-hidden="true">
                {item.icon}
              </span>
              <span className="app-shell__nav-label">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
