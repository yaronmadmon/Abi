/**
 * Me Page
 */

import './Page.css';

export function Me() {
  return (
    <div className="page">
      <h1 className="page__title">Me</h1>
      <p className="page__description">Your personal space</p>
    </div>
  );
}
